// All timing derives from the SRT / voiceover. Values are in seconds (absolute).
export const TOTAL_SEC = 34.6;

export type SceneId = "hook" | "turf" | "features" | "progress" | "gear" | "booking" | "logo";

export const SCENES: {id: SceneId; start: number; end: number}[] = [
  {id: "hook", start: 0, end: 5.62},
  {id: "turf", start: 5.62, end: 12.3},
  {id: "features", start: 12.3, end: 17.1},
  {id: "progress", start: 17.1, end: 24.8},
  {id: "gear", start: 24.8, end: 28.0},
  {id: "booking", start: 28.0, end: 32.4},
  {id: "logo", start: 32.4, end: TOTAL_SEC},
];

export type SfxName = "pop" | "click" | "tick" | "whoosh" | "chime" | "impact";

// Absolute seconds. Kept sparse: only entries, card reveals, checks, transitions, emphasis.
export const SFX: {at: number; name: SfxName; vol: number; rate?: number}[] = [
  {at: 0.0, name: "whoosh", vol: 0.22},
  {at: 1.65, name: "pop", vol: 0.26, rate: 1.0},
  {at: 3.85, name: "pop", vol: 0.3, rate: 1.12},
  {at: 5.3, name: "whoosh", vol: 0.22},
  {at: 7.5, name: "pop", vol: 0.26, rate: 0.96},
  {at: 8.85, name: "impact", vol: 0.28},
  {at: 9.97, name: "pop", vol: 0.24, rate: 1.05},
  {at: 11.02, name: "chime", vol: 0.24},
  {at: 12.05, name: "whoosh", vol: 0.22},
  {at: 12.45, name: "pop", vol: 0.28, rate: 0.98},
  {at: 14.0, name: "pop", vol: 0.28, rate: 1.06},
  {at: 15.5, name: "pop", vol: 0.24, rate: 1.0},
  {at: 16.95, name: "whoosh", vol: 0.22},
  {at: 17.4, name: "tick", vol: 0.25},
  {at: 18.9, name: "click", vol: 0.3},
  {at: 20.95, name: "whoosh", vol: 0.2},
  {at: 21.1, name: "pop", vol: 0.26, rate: 0.97},
  {at: 22.65, name: "pop", vol: 0.26, rate: 1.08},
  {at: 23.45, name: "impact", vol: 0.24},
  {at: 24.55, name: "whoosh", vol: 0.22},
  {at: 25.1, name: "pop", vol: 0.28, rate: 0.98},
  {at: 25.8, name: "click", vol: 0.3},
  {at: 26.2, name: "pop", vol: 0.28, rate: 1.06},
  {at: 26.9, name: "click", vol: 0.3, rate: 1.05},
  {at: 27.75, name: "whoosh", vol: 0.22},
  {at: 28.15, name: "pop", vol: 0.28, rate: 0.98},
  {at: 28.95, name: "pop", vol: 0.28, rate: 1.04},
  {at: 29.35, name: "click", vol: 0.28},
  {at: 29.7, name: "pop", vol: 0.28, rate: 1.1},
  {at: 30.05, name: "tick", vol: 0.25},
  {at: 30.6, name: "pop", vol: 0.26, rate: 1.0},
  {at: 32.15, name: "whoosh", vol: 0.24},
  {at: 32.55, name: "chime", vol: 0.3},
  {at: 33.4, name: "impact", vol: 0.26},
];
