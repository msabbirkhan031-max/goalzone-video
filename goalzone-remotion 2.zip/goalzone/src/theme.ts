import {Easing} from "remotion";
import {loadFont} from "@remotion/google-fonts/HindSiliguri";

// Bengali-friendly family (ligatures intact). Loaded from Google Fonts at render time.
const {fontFamily} = loadFont("normal", {
  weights: ["500", "700"],
  subsets: ["bengali", "latin"],
});

// Scheme 1 — Golden Night Pitch
export const theme = {
  font: fontFamily,
  weight: {regular: 500 as const, bold: 700 as const},
  colors: {
    bg: "#07130D",
    bgDeep: "#040B07",
    hero: "#D4A62A",
    heroSoft: "#F3E3A0",
    accent: "#2ECC71",
    text: "#F8F5E8",
    textDim: "rgba(248,245,232,0.66)",
    heroGlow: "rgba(212,166,42,0.42)",
    heroFaint: "rgba(212,166,42,0.16)",
    accentGlow: "rgba(46,204,113,0.35)",
    glass: "rgba(248,245,232,0.06)",
    glassBorder: "rgba(212,166,42,0.38)",
    track: "rgba(248,245,232,0.10)",
    line: "rgba(248,245,232,0.34)",
    meshA: "rgba(46,204,113,0.16)",
    meshB: "rgba(212,166,42,0.14)",
    meshC: "rgba(18,86,52,0.40)",
    beam: "rgba(243,227,160,0.20)",
    turfA: "#0F5A33",
    turfB: "#13703F",
    gradeTop: "rgba(10,60,50,0.22)",
    gradeBottom: "rgba(120,80,10,0.16)",
    vignette: "rgba(0,0,0,0.62)",
    ballLight: "#F4F1E6",
    ballDark: "#0B1A12",
    shadow: "rgba(0,0,0,0.5)",
    onHero: "#07130D",
  },
  radius: 32,
  radiusSm: 18,
  space: 8,
  shadow: "0 30px 80px rgba(0,0,0,0.5), 0 0 0 1px rgba(248,245,232,0.04)",
  easing: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.65, 0, 0.35, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  springs: {
    smooth: {damping: 200},
    snappy: {damping: 20, stiffness: 170, mass: 0.9},
    pop: {damping: 11, stiffness: 190, mass: 0.8},
    gentle: {damping: 26, stiffness: 90},
  },
  exitSec: 0.3,
};

export type SpringName = keyof typeof theme.springs;
