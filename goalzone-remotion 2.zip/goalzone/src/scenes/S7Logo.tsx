import React from "react";
import {AbsoluteFill, Img, staticFile} from "remotion";
import {theme} from "../theme";
import {useBreathe, useEnter, useProgress} from "../anim";
import {Slot, Words} from "../components/Text";
import {Dust} from "../components/Layers";

const LOGO_W = 598; // 762x714 source, aspect preserved
const LOGO_H = 560;

// Scene 7 — Logo reveal with gold sweep + payoff line.
export const S7Logo: React.FC = () => {
  const p = useEnter(0.12, "smooth");
  const pop = useEnter(0.12, "gentle");
  const sweep = useProgress(0.55, 0.9, theme.easing.inOut);
  const halo = useProgress(0.05, 1.2, theme.easing.out);
  const breathe = useBreathe(0.012, 3.2);
  const float = useBreathe(5, 3.2);
  const blur = (1 - Math.min(1, p)) * 14;
  const logoUrl = staticFile("assets/logo.png");

  return (
    <AbsoluteFill>
      <Dust count={34} speed={30} size={7} />
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "41%",
          width: 900,
          height: 900,
          transform: `translate(-50%,-50%) scale(${0.6 + 0.4 * halo})`,
          borderRadius: "50%",
          background: `radial-gradient(circle, ${theme.colors.heroGlow} 0%, transparent 62%)`,
          opacity: halo,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "41%",
          width: LOGO_W,
          height: LOGO_H,
          transform: `translate(-50%,-50%) translateY(${float + (1 - Math.min(1, pop)) * 40}px) scale(${(0.86 + 0.14 * Math.min(1.04, pop)) * (1 + breathe)})`,
          opacity: Math.min(1, p * 1.5),
          filter: `blur(${blur}px) drop-shadow(0 0 40px ${theme.colors.heroGlow})`,
        }}
      >
        <Img src={logoUrl} style={{width: LOGO_W, height: LOGO_H, objectFit: "contain", display: "block"}} />
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: `linear-gradient(105deg, transparent 38%, ${theme.colors.text} 50%, transparent 62%)`,
            backgroundSize: "300% 100%",
            backgroundPositionX: `${100 - sweep * 100}%`,
            backgroundRepeat: "no-repeat",
            WebkitMaskImage: `url(${logoUrl})`,
            maskImage: `url(${logoUrl})`,
            WebkitMaskSize: "contain",
            maskSize: "contain",
            WebkitMaskRepeat: "no-repeat",
            maskRepeat: "no-repeat",
            WebkitMaskPosition: "center",
            maskPosition: "center",
            opacity: sweep > 0 && sweep < 1 ? 0.75 : 0,
            mixBlendMode: "screen",
          }}
        />
      </div>
      <Slot top="86%">
        <Words text="Get ready to play!" start={0.95} size={96} gradient stagger={5} />
      </Slot>
    </AbsoluteFill>
  );
};
