import React from "react";
import {AbsoluteFill} from "remotion";
import {theme} from "../theme";
import {useBreathe, useProgress} from "../anim";
import {Slot, Words} from "../components/Text";
import {Reveal} from "../components/Reveal";
import {Card} from "../components/Card";
import {Floodlight, Grass} from "../components/Icons";

const Label: React.FC<{small: string; big: string}> = ({small, big}) => (
  <div style={{textAlign: "center", fontFamily: theme.font}}>
    <div style={{fontSize: 44, fontWeight: theme.weight.regular, color: theme.colors.textDim, lineHeight: 1.3}}>{small}</div>
    <div style={{fontSize: 84, fontWeight: theme.weight.bold, color: theme.colors.text, lineHeight: 1.3}}>{big}</div>
  </div>
);

// Scene 3 — Bento pair: artificial grass + floodlight.
export const S3Features: React.FC = () => {
  const grass = useProgress(0.35, 1.0, theme.easing.out);
  const pole = useProgress(1.85, 0.5, theme.easing.out);
  const lightOn = useProgress(2.35, 0.6, theme.easing.inOut);
  const float1 = useBreathe(6, 3.2, 0);
  const float2 = useBreathe(6, 3.2, 1.6);

  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: "43%",
          transform: "translateY(-50%)",
          display: "flex",
          justifyContent: "center",
          gap: 80,
        }}
      >
        <Reveal delay={0.15} y={70} preset="pop">
          <div style={{transform: `translateY(${float1}px)`}}>
            <Card width={800} height={620}>
              <Grass size={300} p={grass} />
              <Label small="বিশ্বমানের" big="কৃত্রিম ঘাস" />
            </Card>
          </div>
        </Reveal>
        <Reveal delay={1.7} y={70} preset="pop">
          <div style={{transform: `translateY(${float2}px)`}}>
            <Card width={800} height={620}>
              <Floodlight size={300} p={pole} on={lightOn} />
              <Label small="শক্তিশালী" big="Floodlight" />
            </Card>
          </div>
        </Reveal>
      </div>
      <Slot top="88%">
        <Words text="সবকিছুই থাকছে এখানে" start={3.15} size={76} weight={500} hero={["এখানে"]} />
      </Slot>
    </AbsoluteFill>
  );
};
