import React from "react";
import {AbsoluteFill, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {clamp01, useBreathe, useEnter, useProgress} from "../anim";
import {Stack, Words} from "../components/Text";
import {Ball, PitchLines} from "../components/Icons";

// Scene 1 — Hook. Kinetic typography over a self-drawing pitch; ball rolls in.
export const S1Hook: React.FC = () => {
  const {width} = useVideoConfig();
  const lines = useProgress(0.05, 1.7, theme.easing.inOut);
  const roll = useProgress(0.2, 1.5, theme.easing.out);
  const bob = useBreathe(7, 2.6);
  const bumpT = useProgress(3.85, 0.55, theme.easing.inOut);
  const bump = 1 + 0.28 * Math.sin(Math.PI * clamp01(bumpT));
  const pitchIn = useEnter(0, "gentle");
  const ballSize = 150;
  const x = -240 + (width / 2 + 240) * roll; // from off-screen left to centre
  const rotation = (x / (ballSize * Math.PI)) * 360;
  const glow = clamp01(bumpT) * 0.9 + 0.25;

  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "62%",
          width: 1300,
          height: 823,
          transform: "translate(-50%,-50%) perspective(1500px) rotateX(58deg)",
          opacity: 0.55 * pitchIn,
        }}
      >
        <PitchLines p={lines} />
      </div>

      <Stack top="31%">
        <div style={{display: "flex", flexDirection: "column", alignItems: "center", gap: 10}}>
          <Words text="খুলনার ফুটবল প্রেমী" start={0} exit={2.5} size={132} hero={["ফুটবল"]} />
          <Words text="বন্ধুরা" start={1.55} exit={2.5} size={96} weight={500} color={theme.colors.textDim} />
        </div>
        <Words text="কেমন আছেন সবাই?" start={2.55} exit={3.75} size={120} />
        <Words text="দারুণ খবর!" start={3.85} size={190} gradient />
      </Stack>

      <div
        style={{
          position: "absolute",
          left: x - ballSize / 2,
          top: 700 + bob - ballSize / 2,
          width: ballSize,
          height: ballSize,
          transform: `scale(${bump})`,
          filter: `drop-shadow(0 0 ${40 * glow}px ${theme.colors.heroGlow}) drop-shadow(0 24px 24px ${theme.colors.shadow})`,
        }}
      >
        <Ball size={ballSize} rotate={rotation} />
      </div>
    </AbsoluteFill>
  );
};
