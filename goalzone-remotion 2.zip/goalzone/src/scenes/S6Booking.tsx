import React from "react";
import {AbsoluteFill} from "remotion";
import {theme} from "../theme";
import {clamp01, useBreathe, useEnter, useProgress} from "../anim";

import {Reveal} from "../components/Reveal";
import {Card} from "../components/Card";
import {Bell, Check, Eye} from "../components/Icons";

const Name: React.FC<{text: string}> = ({text}) => (
  <div style={{fontFamily: theme.font, fontWeight: theme.weight.bold, fontSize: 62, color: theme.colors.text, lineHeight: 1.3}}>
    {text}
  </div>
);

// Calendar grid made of rounded cells; one cell lights up (no invented dates).
const CalendarGrid: React.FC<{hit: number}> = ({hit}) => (
  <div style={{display: "grid", gridTemplateColumns: "repeat(7, 38px)", gap: 8}}>
    {Array.from({length: 28}, (_, i) => {
      const on = i === 17;
      return (
        <div
          key={i}
          style={{
            width: 38,
            height: 38,
            borderRadius: 9,
            background: on ? theme.colors.hero : theme.colors.track,
            transform: on ? `scale(${1 + 0.18 * hit})` : undefined,
            boxShadow: on ? `0 0 ${26 * hit}px ${theme.colors.heroGlow}` : undefined,
          }}
        />
      );
    })}
  </div>
);

// Slot rows; the middle one gets selected.
const SlotRows: React.FC<{sel: number}> = ({sel}) => (
  <div style={{display: "flex", flexDirection: "column", gap: 16, width: 380}}>
    {[0, 1, 2].map((i) => {
      const on = i === 1;
      return (
        <div
          key={i}
          style={{
            height: 58,
            borderRadius: 29,
            background: on ? `rgba(46,204,113,${0.16 + 0.5 * sel})` : theme.colors.track,
            border: `2px solid ${on && sel > 0.2 ? theme.colors.accent : theme.colors.glassBorder}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 14px 0 26px",
          }}
        >
          <div style={{width: 120 + i * 24, height: 12, borderRadius: 6, background: theme.colors.line}} />
          {on ? <Check size={36} p={sel} /> : null}
        </div>
      );
    })}
  </div>
);

// Scene 6 — Bento row: date / slot booking / updates, then "watch our page".
export const S6Booking: React.FC = () => {
  const cal = useProgress(0.6, 0.5, theme.easing.out);
  const sel = useProgress(1.35, 0.5, theme.easing.out);
  const f0 = useBreathe(5, 3, 0);
  const f1 = useBreathe(5, 3, 1.0);
  const f2 = useBreathe(5, 3, 2.0);
  const badge = useEnter(2.05, "pop");
  const ringT = useProgress(2.05, 1.2, (t) => t);
  const swing = Math.sin(ringT * 26) * 16 * (1 - ringT);
  const ripple = clamp01(ringT * 1.6);

  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: "43%",
          transform: "translateY(-50%)",
          display: "flex",
          justifyContent: "center",
          gap: 56,
        }}
      >
        <Reveal delay={0.1} y={70} preset="pop">
          <div style={{transform: `translateY(${f0}px)`}}>
            <Card width={520} height={500}>
              <CalendarGrid hit={cal} />
              <Name text="খেলার তারিখ" />
            </Card>
          </div>
        </Reveal>
        <Reveal delay={0.95} y={70} preset="pop">
          <div style={{transform: `translateY(${f1}px)`}}>
            <Card width={520} height={500}>
              <SlotRows sel={sel} />
              <Name text="Slot Booking" />
            </Card>
          </div>
        </Reveal>
        <Reveal delay={1.7} y={70} preset="pop">
          <div style={{transform: `translateY(${f2}px)`}}>
            <Card width={520} height={500}>
              <div style={{position: "relative", width: 200, height: 200}}>
                <div
                  style={{
                    position: "absolute",
                    inset: 20,
                    borderRadius: "50%",
                    border: `3px solid ${theme.colors.hero}`,
                    opacity: (1 - ripple) * 0.8,
                    transform: `scale(${0.7 + ripple * 0.9})`,
                  }}
                />
                <Bell size={200} swing={swing} />
                <div
                  style={{
                    position: "absolute",
                    right: 24,
                    top: 22,
                    width: 38,
                    height: 38,
                    borderRadius: "50%",
                    background: theme.colors.accent,
                    border: `4px solid ${theme.colors.bg}`,
                    transform: `scale(${Math.min(1.2, badge)})`,
                  }}
                />
              </div>
              <Name text="Update" />
            </Card>
          </div>
        </Reveal>
      </div>

      <Reveal
        delay={2.6}
        y={40}
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: "85%",
          display: "flex",
          justifyContent: "center",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 26,
            padding: "10px 52px 18px 40px",
            borderRadius: 999,
            border: `2px solid ${theme.colors.glassBorder}`,
            background: theme.colors.glass,
            boxShadow: theme.shadow,
          }}
        >
          <Eye size={78} />
          <div style={{fontFamily: theme.font, fontWeight: theme.weight.bold, fontSize: 70, color: theme.colors.text, lineHeight: 1.3}}>
            আমাদের Page-এ <span style={{color: theme.colors.hero}}>চোখ রাখুন</span>
          </div>
        </div>
      </Reveal>
    </AbsoluteFill>
  );
};
