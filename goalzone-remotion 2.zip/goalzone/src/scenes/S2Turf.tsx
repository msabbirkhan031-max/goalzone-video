import React from "react";
import {AbsoluteFill} from "remotion";
import {theme} from "../theme";
import {useBreathe, useProgress} from "../anim";
import {Slot, Stack, Words} from "../components/Text";
import {Reveal} from "../components/Reveal";

// Scene 2 — Premium turf rises from the bottom as a striped 3D plane.
export const S2Turf: React.FC = () => {
  const rise = useProgress(0.05, 1.3, theme.easing.out);
  const drift = useBreathe(40, 6);
  const sheen = useProgress(3.2, 1.6, theme.easing.inOut);

  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: "50%",
          bottom: 40 - (1 - rise) * 640,
          width: 3000,
          height: 1500,
          transform: "translateX(-50%) perspective(1100px) rotateX(66deg)",
          transformOrigin: "50% 100%",
          background: `repeating-linear-gradient(90deg, ${theme.colors.turfA} 0 150px, ${theme.colors.turfB} 150px 300px)`,
          backgroundPositionX: drift,
          boxShadow: `0 -40px 120px ${theme.colors.accentGlow}`,
          opacity: 0.95,
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: `linear-gradient(180deg, ${theme.colors.bgDeep} 0%, transparent 55%)`,
          }}
        />
        <div
          style={{
            position: "absolute",
            top: 0,
            bottom: 0,
            width: 340,
            left: `${-10 + sheen * 120}%`,
            background: `linear-gradient(100deg, transparent, ${theme.colors.beam}, transparent)`,
            opacity: sheen > 0 && sheen < 1 ? 0.9 : 0,
          }}
        />
      </div>

      <Stack top="28%">
        <Words text="খুলনায় আসছে" start={0.1} exit={1.85} size={128} />
        <Words text="একদম নতুন" start={1.95} exit={3.15} size={128} hero={["নতুন"]} />
      </Stack>

      <Slot top="33%">
        <Words text="PREMIUM TURF" start={3.2} size={190} gradient stagger={6} />
      </Slot>

      <Stack top="56%">
        <Words text="খেলার অভিজ্ঞতা" start={4.35} exit={5.35} size={104} />
        <Words text="সম্পূর্ণ বদলে দিবে" start={5.4} size={104} hero={["বদলে", "দিবে"]} />
      </Stack>
      <Reveal delay={3.2} style={{position: "absolute", left: 0, right: 0, top: "46%", display: "flex", justifyContent: "center"}}>
        <div
          style={{
            width: 260,
            height: 6,
            borderRadius: 3,
            background: `linear-gradient(90deg, transparent, ${theme.colors.hero}, transparent)`,
          }}
        />
      </Reveal>
    </AbsoluteFill>
  );
};
