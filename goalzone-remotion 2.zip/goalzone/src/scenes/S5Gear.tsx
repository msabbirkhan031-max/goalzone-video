import React from "react";
import {AbsoluteFill} from "remotion";
import {theme} from "../theme";
import {useBreathe, useProgress} from "../anim";
import {Slot, Words} from "../components/Text";
import {Reveal} from "../components/Reveal";
import {Card} from "../components/Card";
import {Boot, Check, Jersey} from "../components/Icons";

const Name: React.FC<{text: string}> = ({text}) => (
  <div style={{fontFamily: theme.font, fontWeight: theme.weight.bold, fontSize: 84, color: theme.colors.text, lineHeight: 1.3}}>
    {text}
  </div>
);

// Scene 5 — Readiness checklist cards.
export const S5Gear: React.FC = () => {
  const bootP = useProgress(0.4, 0.8, theme.easing.out);
  const check1 = useProgress(1.0, 0.5, theme.easing.out);
  const jerseyP = useProgress(1.5, 0.8, theme.easing.out);
  const check2 = useProgress(2.1, 0.5, theme.easing.out);
  const f1 = useBreathe(6, 3, 0);
  const f2 = useBreathe(6, 3, 1.5);

  return (
    <AbsoluteFill>
      <Slot top="17%">
        <Words text="প্রস্তুত থাকুন" start={0.0} size={116} hero={["প্রস্তুত"]} />
      </Slot>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: "58%",
          transform: "translateY(-50%)",
          display: "flex",
          justifyContent: "center",
          gap: 80,
        }}
      >
        <Reveal delay={0.3} y={70} preset="pop">
          <div style={{transform: `translateY(${f1}px)`}}>
            <Card width={640} height={560}>
              <Boot size={210} p={bootP} />
              <Name text="Turf Shoe" />
              <Check size={84} p={check1} />
            </Card>
          </div>
        </Reveal>
        <Reveal delay={1.4} y={70} preset="pop">
          <div style={{transform: `translateY(${f2}px)`}}>
            <Card width={640} height={560}>
              <Jersey size={210} p={jerseyP} />
              <Name text="Gears" />
              <Check size={84} p={check2} />
            </Card>
          </div>
        </Reveal>
      </div>
    </AbsoluteFill>
  );
};
