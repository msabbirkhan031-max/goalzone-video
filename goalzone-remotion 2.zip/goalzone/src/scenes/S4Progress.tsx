import React from "react";
import {AbsoluteFill} from "remotion";
import {theme} from "../theme";
import {clamp01, useBreathe, useEnter, useProgress} from "../anim";
import {Slot, Words} from "../components/Text";
import {Reveal} from "../components/Reveal";
import {Ball} from "../components/Icons";

// Cubic bezier for the ball's run into the goal (1920x1080 space).
const P0 = {x: 200, y: 900};
const P1 = {x: 640, y: 420};
const P2 = {x: 1060, y: 1040};
const P3 = {x: 1660, y: 690};
const bez = (t: number) => {
  const u = 1 - t;
  return {
    x: u * u * u * P0.x + 3 * u * u * t * P1.x + 3 * u * t * t * P2.x + t * t * t * P3.x,
    y: u * u * u * P0.y + 3 * u * u * t * P1.y + 3 * u * t * t * P2.y + t * t * t * P3.y,
  };
};

// Scene 4 — Phase 1: construction progress meter (no invented numbers).
// Phase 2: line-draw run of the ball into the goal.
export const S4Progress: React.FC = () => {
  const fill = useProgress(0.3, 1.5, theme.easing.inOut);
  const pulse = 0.5 + 0.5 * Math.sin(useProgress(1.8, 3, (t) => t) * 40);
  const run = useProgress(4.1, 2.2, theme.easing.inOut);
  const net = useProgress(6.3, 0.5, theme.easing.out);
  const goalIn = useEnter(3.95, "gentle");
  const bob = useBreathe(4, 2.4);

  const barW = 1300;
  const fillW = barW * 0.92 * fill;

  const pts: string[] = [];
  const steps = 48;
  for (let i = 0; i <= steps; i++) {
    const t = (i / steps) * run;
    if (i / steps > run) break;
    const p = bez(t);
    pts.push(`${p.x},${p.y}`);
  }
  const ball = bez(run);
  const ballSize = 96;

  return (
    <AbsoluteFill>
      {/* Phase 1 */}
      <Slot top="32%">
        <Words text="নির্মাণকাজ" start={0.15} exit={3.85} size={118} />
      </Slot>
      <Reveal delay={0.25} exit={3.85} y={30} style={{position: "absolute", left: (1920 - barW) / 2, top: 500}}>
        <div
          style={{
            width: barW,
            height: 64,
            borderRadius: 32,
            background: theme.colors.track,
            border: `2px solid ${theme.colors.glassBorder}`,
            overflow: "hidden",
            boxShadow: theme.shadow,
          }}
        >
          <div
            style={{
              width: fillW,
              height: "100%",
              borderRadius: 32,
              background: `linear-gradient(90deg, ${theme.colors.accent}, ${theme.colors.hero})`,
              boxShadow: `0 0 ${24 + pulse * 26}px ${theme.colors.heroGlow}`,
            }}
          />
        </div>
      </Reveal>
      <Reveal delay={1.45} exit={3.85} style={{position: "absolute", left: 0, right: 0, top: 594, display: "flex", justifyContent: "center"}}>
        <div
          style={{
            fontFamily: theme.font,
            fontWeight: theme.weight.bold,
            fontSize: 52,
            color: theme.colors.onHero,
            background: theme.colors.hero,
            padding: "6px 36px 12px",
            borderRadius: 999,
            boxShadow: `0 0 ${20 + pulse * 20}px ${theme.colors.heroGlow}`,
          }}
        >
          প্রায় শেষ
        </div>
      </Reveal>
      <Slot top="76%">
        <Words text="আর বেশিদিন অপেক্ষা নয়" start={2.0} exit={3.85} size={80} weight={500} hero={["অপেক্ষা"]} />
      </Slot>

      {/* Phase 2 */}
      <svg width="1920" height="1080" viewBox="0 0 1920 1080" style={{position: "absolute", inset: 0}}>
        <g opacity={goalIn}>
          <rect x="1560" y="560" width="220" height="260" fill="none" stroke={theme.colors.text} strokeWidth="8" rx="4" />
          {[1, 2, 3, 4].map((i) => (
            <line key={`v${i}`} x1={1560 + i * 44} y1="560" x2={1560 + i * 44} y2="820" stroke={theme.colors.hero} strokeWidth="2" opacity={0.25 + net * 0.6} />
          ))}
          {[1, 2, 3, 4].map((i) => (
            <line key={`h${i}`} x1="1560" y1={560 + i * 52} x2="1780" y2={560 + i * 52} stroke={theme.colors.hero} strokeWidth="2" opacity={0.25 + net * 0.6} />
          ))}
        </g>
        {pts.length > 1 && (
          <polyline
            points={pts.join(" ")}
            fill="none"
            stroke={theme.colors.hero}
            strokeWidth="8"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="4 22"
            opacity={0.9}
          />
        )}
      </svg>
      {run > 0 && (
        <div
          style={{
            position: "absolute",
            left: ball.x - ballSize / 2,
            top: ball.y - ballSize / 2 + (run >= 1 ? bob : 0),
            width: ballSize,
            height: ballSize,
            filter: `drop-shadow(0 0 ${18 + clamp01(net) * 30}px ${theme.colors.heroGlow})`,
          }}
        >
          <Ball size={ballSize} rotate={run * 900} />
        </div>
      )}
      <Slot top="22%">
        <Words text="বন্ধুদের সাথে" start={4.0} exit={5.5} size={112} />
      </Slot>
      <Slot top="22%">
        <Words text="সেরাটা দিতে তৈরি থাকুন" start={5.55} size={104} hero={["তৈরি", "থাকুন"]} />
      </Slot>
    </AbsoluteFill>
  );
};
