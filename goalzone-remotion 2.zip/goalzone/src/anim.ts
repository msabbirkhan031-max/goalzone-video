import {interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "./theme";
import type {SpringName} from "./theme";

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

export const rand = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

// Spring progress that starts at `delaySec` (scene-local seconds).
export const useEnter = (delaySec: number, preset: SpringName = "snappy") => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - Math.round(delaySec * fps), fps, config: theme.springs[preset]});
};

// Eased 0..1 progress between startSec and startSec+durSec.
export const useProgress = (
  startSec: number,
  durSec: number,
  easing: (t: number) => number = theme.easing.out,
) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return interpolate(frame, [startSec * fps, (startSec + durSec) * fps], [0, 1], {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

// Exits are faster than entrances.
export const useExit = (startSec: number | undefined, durSec: number = theme.exitSec) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (startSec === undefined) return 0;
  return interpolate(frame, [startSec * fps, (startSec + durSec) * fps], [0, 1], {
    easing: theme.easing.in,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};

// Idle micro-motion.
export const useBreathe = (amp: number, periodSec = 3.4, phase = 0) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return Math.sin((frame / fps) * ((Math.PI * 2) / periodSec) + phase) * amp;
};
