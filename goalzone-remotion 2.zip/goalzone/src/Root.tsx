import React from "react";
import {Composition} from "remotion";
import {Main} from "./Main";
import {FPS, HEIGHT, WIDTH} from "./config";
import {TOTAL_SEC} from "./timeline";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={Math.round(TOTAL_SEC * FPS)}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
