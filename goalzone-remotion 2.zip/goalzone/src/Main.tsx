import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile, useVideoConfig} from "remotion";
import {Bg, Grade, Grain, Vignette} from "./components/Layers";
import {SceneShell} from "./components/SceneShell";
import {SfxTrack} from "./components/Sfx";
import {PLAY_SFX, PLAY_VOICEOVER} from "./config";
import {SCENES} from "./timeline";
import type {SceneId} from "./timeline";
import {S1Hook} from "./scenes/S1Hook";
import {S2Turf} from "./scenes/S2Turf";
import {S3Features} from "./scenes/S3Features";
import {S4Progress} from "./scenes/S4Progress";
import {S5Gear} from "./scenes/S5Gear";
import {S6Booking} from "./scenes/S6Booking";
import {S7Logo} from "./scenes/S7Logo";

const SCENE_MAP: Record<SceneId, React.FC> = {
  hook: S1Hook,
  turf: S2Turf,
  features: S3Features,
  progress: S4Progress,
  gear: S5Gear,
  booking: S6Booking,
  logo: S7Logo,
};

export const Main: React.FC = () => {
  const {fps, durationInFrames} = useVideoConfig();
  return (
    <AbsoluteFill>
      {/* layer 1: background mesh */}
      <Bg />
      {/* layers 2-3: scene assets + graphics + type */}
      {SCENES.map((s, i) => {
        const from = Math.round(s.start * fps);
        const last = i === SCENES.length - 1;
        const to = last ? durationInFrames : Math.round(s.end * fps);
        const frames = to - from;
        const Scene = SCENE_MAP[s.id];
        return (
          <Sequence key={s.id} from={from} durationInFrames={frames} name={s.id}>
            <SceneShell frames={frames} exit={!last}>
              <Scene />
            </SceneShell>
          </Sequence>
        );
      })}
      {/* layer 4: grade, layer 5: grain + vignette */}
      <Grade />
      <Grain />
      <Vignette />
      {PLAY_VOICEOVER ? <Audio src={staticFile("voiceover.mp3")} volume={1} /> : null}
      {PLAY_SFX ? <SfxTrack /> : null}
    </AbsoluteFill>
  );
};
