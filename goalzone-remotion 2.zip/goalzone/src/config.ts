// Preview switches. Set to false to mute in Studio / render.
export const PLAY_VOICEOVER = true; // reads public/voiceover.mp3
export const PLAY_SFX = true; // reads public/sfx/*.wav

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
