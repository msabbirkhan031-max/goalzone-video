import React from "react";
import {useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {useEnter, useExit} from "../anim";

const Word: React.FC<{
  word: string;
  delay: number;
  size: number;
  hero: boolean;
  gradient: boolean;
}> = ({word, delay, size, hero, gradient}) => {
  const frame = useCurrentFrame();
  const p = useEnter(delay, "snappy");
  const inner: React.CSSProperties = {
    display: "inline-block",
    transform: `translateY(${(1 - p) * 115}%) scale(${0.94 + 0.06 * Math.min(1, p)})`,
    opacity: Math.min(1, p * 1.6),
  };
  if (gradient) {
    inner.backgroundImage = `linear-gradient(100deg, ${theme.colors.hero}, ${theme.colors.heroSoft}, ${theme.colors.hero})`;
    inner.backgroundSize = "220% 100%";
    inner.backgroundPosition = `${(frame * 1.2) % 220}% 0`;
    inner.WebkitBackgroundClip = "text";
    inner.backgroundClip = "text";
    inner.WebkitTextFillColor = "transparent";
    inner.color = "transparent";
  } else if (hero) {
    inner.color = theme.colors.hero;
  }
  // Mask: overflow hidden with padding so Bengali matras / ref are never clipped.
  return (
    <span
      style={{
        display: "inline-block",
        overflow: "hidden",
        padding: "0.16em 0.08em 0.26em",
        margin: "-0.16em -0.08em -0.26em",
      }}
    >
      <span style={inner}>{word}</span>
    </span>
  );
};

// Word-by-word mask reveal. Splits ONLY on whitespace (never per character) so Bengali
// conjuncts, kars and ref stay intact.
export const Words: React.FC<{
  text: string;
  start: number; // scene-local seconds
  exit?: number; // scene-local seconds
  size: number;
  weight?: 500 | 700;
  color?: string;
  hero?: string[];
  gradient?: boolean; // whole phrase gradient
  stagger?: number; // frames between words
}> = ({text, start, exit, size, weight = 700, color, hero = [], gradient = false, stagger = 4}) => {
  const {fps} = useVideoConfig();
  const ex = useExit(exit);
  const words = text.split(/\s+/).filter(Boolean);
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        columnGap: Math.round(size * 0.28),
        rowGap: Math.round(size * 0.04),
        fontFamily: theme.font,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.3,
        letterSpacing: 0,
        textAlign: "center",
        color: color ?? theme.colors.text,
        opacity: 1 - ex,
        transform: `translateY(${-ex * 22}px) scale(${1 + ex * 0.03})`,
        filter: gradient || hero.length ? `drop-shadow(0 0 22px ${theme.colors.heroGlow})` : undefined,
      }}
    >
      {words.map((w, i) => (
        <Word
          key={i}
          word={w}
          delay={start + (i * stagger) / fps}
          size={size}
          hero={hero.includes(w)}
          gradient={gradient}
        />
      ))}
    </div>
  );
};

// Horizontally centred slot at a given vertical position.
export const Slot: React.FC<{top: string; children?: React.ReactNode}> = ({top, children}) => (
  <div
    style={{
      position: "absolute",
      left: 0,
      right: 0,
      top,
      transform: "translateY(-50%)",
      padding: "0 140px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 16,
    }}
  >
    {children}
  </div>
);

// Stacked slot: several phrases occupying the same spot (they exit as the next enters).
export const Stack: React.FC<{top: string; children?: React.ReactNode}> = ({top, children}) => (
  <div
    style={{
      position: "absolute",
      left: 0,
      right: 0,
      top,
      transform: "translateY(-50%)",
      padding: "0 140px",
      display: "grid",
      justifyItems: "center",
      alignItems: "center",
    }}
  >
    {React.Children.map(children, (c) => (
      <div style={{gridArea: "1 / 1"}}>{c}</div>
    ))}
  </div>
);
