import React from "react";
import {Audio, Sequence, staticFile, useVideoConfig} from "remotion";
import {SFX} from "../timeline";

export const SfxTrack: React.FC = () => {
  const {fps} = useVideoConfig();
  return (
    <>
      {SFX.map((e, i) => (
        <Sequence key={i} from={Math.round(e.at * fps)} durationInFrames={Math.round(1 * fps)}>
          <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.vol} playbackRate={e.rate ?? 1} />
        </Sequence>
      ))}
    </>
  );
};
