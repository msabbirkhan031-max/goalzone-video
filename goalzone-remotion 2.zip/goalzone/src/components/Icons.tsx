import React from "react";
import {theme} from "../theme";
import {clamp01} from "../anim";

const C = theme.colors;

export const Ball: React.FC<{size: number; rotate?: number}> = ({size, rotate = 0}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{transform: `rotate(${rotate}deg)`}}>
    <defs>
      <radialGradient id="gz-ball" cx="38%" cy="32%" r="75%">
        <stop offset="0%" stopColor={C.ballLight} />
        <stop offset="100%" stopColor={C.heroSoft} />
      </radialGradient>
    </defs>
    <circle cx="50" cy="50" r="47" fill="url(#gz-ball)" stroke={C.ballDark} strokeWidth="3" />
    <polygon points="50,30 69,44 62,66 38,66 31,44" fill={C.ballDark} />
    <g stroke={C.ballDark} strokeWidth="3" strokeLinecap="round">
      <line x1="50" y1="30" x2="50" y2="5" />
      <line x1="69" y1="44" x2="93" y2="36" />
      <line x1="62" y1="66" x2="77" y2="88" />
      <line x1="38" y1="66" x2="23" y2="88" />
      <line x1="31" y1="44" x2="7" y2="36" />
    </g>
  </svg>
);

// Grass blades that draw upward, staggered. p: 0..1
export const Grass: React.FC<{size: number; p: number}> = ({size, p}) => {
  const blades = [
    {x: 30, lean: -14, h: 92},
    {x: 56, lean: -6, h: 126},
    {x: 82, lean: 4, h: 108},
    {x: 108, lean: 10, h: 134},
    {x: 134, lean: 16, h: 100},
    {x: 160, lean: 20, h: 118},
  ];
  return (
    <svg width={size} height={size} viewBox="0 0 200 200">
      <line x1="10" y1="176" x2="190" y2="176" stroke={C.accent} strokeWidth="6" strokeLinecap="round" opacity={clamp01(p * 2)} />
      {blades.map((b, i) => {
        const bp = clamp01(p * 1.6 - i * 0.12);
        return (
          <path
            key={i}
            d={`M ${b.x} 176 Q ${b.x + b.lean * 0.2} ${176 - b.h * 0.6} ${b.x + b.lean} ${176 - b.h}`}
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={1 - bp}
            stroke={i % 2 ? C.accent : C.heroSoft}
            strokeWidth="11"
            strokeLinecap="round"
            fill="none"
          />
        );
      })}
    </svg>
  );
};

// Floodlight with a beam that switches on. on: 0..1
export const Floodlight: React.FC<{size: number; on: number; p: number}> = ({size, on, p}) => (
  <svg width={size} height={size} viewBox="0 0 200 200" style={{overflow: "visible"}}>
    <defs>
      <linearGradient id="gz-cone" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={C.heroSoft} stopOpacity="0.85" />
        <stop offset="100%" stopColor={C.heroSoft} stopOpacity="0" />
      </linearGradient>
    </defs>
    <polygon points="78,76 122,76 188,220 12,220" fill="url(#gz-cone)" opacity={on * 0.9} />
    <line x1="100" y1="76" x2="100" y2="12" stroke={C.line} strokeWidth="7" strokeLinecap="round" opacity={p} />
    <rect x="52" y="24" width="96" height="54" rx="10" fill={C.bg} stroke={C.hero} strokeWidth="6" opacity={p} />
    {[0, 1, 2].map((r) =>
      [0, 1, 2].map((c) => (
        <circle
          key={`${r}-${c}`}
          cx={72 + c * 28}
          cy={38 + r * 16}
          r="6"
          fill={on > 0.05 ? C.heroSoft : C.track}
          opacity={p * (0.35 + 0.65 * on)}
        />
      )),
    )}
  </svg>
);

export const Check: React.FC<{size: number; p: number}> = ({size, p}) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <circle
      cx="50"
      cy="50"
      r="44"
      fill={C.accent}
      opacity={clamp01(p * 2) * 0.9}
      style={{transform: `scale(${0.6 + 0.4 * clamp01(p * 2)})`, transformOrigin: "50% 50%"}}
    />
    <path
      d="M 28 52 L 44 67 L 73 36"
      pathLength={1}
      strokeDasharray={1}
      strokeDashoffset={1 - clamp01(p * 1.6 - 0.4)}
      stroke={C.onHero}
      strokeWidth="10"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
  </svg>
);

export const Boot: React.FC<{size: number; p: number}> = ({size, p}) => (
  <svg width={size} height={size} viewBox="0 0 140 140">
    <path
      d="M 14 84 C 14 62 34 54 52 54 L 92 54 L 112 72 C 126 76 132 86 132 96 L 14 96 Z"
      pathLength={1}
      strokeDasharray={1}
      strokeDashoffset={1 - clamp01(p * 1.3)}
      fill={C.heroFaint}
      stroke={C.hero}
      strokeWidth="6"
      strokeLinejoin="round"
    />
    {[28, 56, 84, 112].map((x, i) => (
      <rect key={x} x={x - 6} y="102" width="12" height="16" rx="4" fill={C.accent} opacity={clamp01(p * 2 - 0.6 - i * 0.12)} />
    ))}
  </svg>
);

export const Jersey: React.FC<{size: number; p: number}> = ({size, p}) => (
  <svg width={size} height={size} viewBox="0 0 140 140">
    <path
      d="M 30 20 L 55 10 Q 70 26 85 10 L 110 20 L 132 50 L 108 62 L 100 52 L 100 128 L 40 128 L 40 52 L 32 62 L 8 50 Z"
      pathLength={1}
      strokeDasharray={1}
      strokeDashoffset={1 - clamp01(p * 1.3)}
      fill={C.heroFaint}
      stroke={C.hero}
      strokeWidth="6"
      strokeLinejoin="round"
    />
  </svg>
);

export const Bell: React.FC<{size: number; swing: number}> = ({size, swing}) => (
  <svg width={size} height={size} viewBox="0 0 200 200" style={{overflow: "visible"}}>
    <g style={{transformOrigin: "100px 24px", transform: `rotate(${swing}deg)`}}>
      <path
        d="M 100 30 C 70 30 55 55 55 90 L 55 125 L 40 150 L 160 150 L 145 125 L 145 90 C 145 55 130 30 100 30 Z"
        fill={C.heroFaint}
        stroke={C.hero}
        strokeWidth="7"
        strokeLinejoin="round"
      />
      <circle cx="100" cy="172" r="14" fill={C.hero} />
    </g>
  </svg>
);

export const Eye: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <path d="M 6 50 C 24 22 76 22 94 50 C 76 78 24 78 6 50 Z" fill="none" stroke={C.hero} strokeWidth="6" strokeLinejoin="round" />
    <circle cx="50" cy="50" r="15" fill={C.hero} />
    <circle cx="55" cy="45" r="5" fill={C.onHero} />
  </svg>
);

// Top-down pitch markings that draw themselves. p: 0..1
export const PitchLines: React.FC<{p: number}> = ({p}) => {
  const seg = (i: number) => clamp01(p * 1.7 - i * 0.14);
  const common = {
    fill: "none",
    stroke: C.line,
    strokeWidth: 5,
    strokeLinecap: "round" as const,
    pathLength: 1,
    strokeDasharray: 1,
  };
  return (
    <svg viewBox="0 0 1200 760" width="100%" height="100%">
      <rect x="40" y="40" width="1120" height="680" rx="6" {...common} strokeDashoffset={1 - seg(0)} />
      <line x1="600" y1="40" x2="600" y2="720" {...common} strokeDashoffset={1 - seg(1)} />
      <circle cx="600" cy="380" r="110" {...common} strokeDashoffset={1 - seg(2)} />
      <rect x="40" y="220" width="190" height="320" {...common} strokeDashoffset={1 - seg(3)} />
      <rect x="970" y="220" width="190" height="320" {...common} strokeDashoffset={1 - seg(3)} />
      <rect x="40" y="305" width="70" height="150" {...common} strokeDashoffset={1 - seg(4)} />
      <rect x="1090" y="305" width="70" height="150" {...common} strokeDashoffset={1 - seg(4)} />
    </svg>
  );
};
