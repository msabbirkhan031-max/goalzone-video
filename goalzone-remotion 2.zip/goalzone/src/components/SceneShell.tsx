import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";

// Faster exit than entrance (~9 frames at 30fps). Last scene holds (exit=false).
export const SceneShell: React.FC<{frames: number; exit: boolean; children: React.ReactNode}> = ({
  frames,
  exit,
  children,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const exitFrames = Math.round(theme.exitSec * fps);
  const p = exit
    ? interpolate(frame, [frames - exitFrames, frames], [0, 1], {
        easing: theme.easing.in,
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      })
    : 0;
  return (
    <AbsoluteFill style={{opacity: 1 - p, transform: `scale(${1 + p * 0.03})`}}>
      {children}
    </AbsoluteFill>
  );
};
