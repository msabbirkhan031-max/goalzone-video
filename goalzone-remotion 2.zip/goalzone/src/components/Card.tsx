import React from "react";
import {theme} from "../theme";

export const Card: React.FC<{
  width: number;
  height: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({width, height, style, children}) => (
  <div
    style={{
      width,
      height,
      borderRadius: theme.radius,
      background: theme.colors.glass,
      border: `2px solid ${theme.colors.glassBorder}`,
      boxShadow: theme.shadow,
      backdropFilter: "blur(14px)",
      WebkitBackdropFilter: "blur(14px)",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: 28,
      position: "relative",
      overflow: "hidden",
      ...style,
    }}
  >
    {children}
  </div>
);
