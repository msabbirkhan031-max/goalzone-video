import React from "react";
import {useEnter, useExit} from "../anim";
import type {SpringName} from "../theme";

// Entrance animates opacity + translateY + scale together. Exit is faster.
export const Reveal: React.FC<{
  delay: number;
  exit?: number;
  y?: number;
  from?: number;
  preset?: SpringName;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({delay, exit, y = 48, from = 0.9, preset = "snappy", style, children}) => {
  const p = useEnter(delay, preset);
  const ex = useExit(exit);
  const opacity = Math.min(1, Math.max(0, p * 1.4)) * (1 - ex);
  const ty = (1 - p) * y - ex * 18;
  const sc = from + (1 - from) * p - ex * 0.04;
  return (
    <div style={{opacity, transform: `translateY(${ty}px) scale(${sc})`, ...style}}>{children}</div>
  );
};
