import React from "react";
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {rand} from "../anim";

// Layer 1: animated background mesh + floodlight beams + faint turf stripes + dust.
export const Bg: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;

  const blob = (
    cx: number,
    cy: number,
    r: number,
    color: string,
    sx: number,
    sy: number,
    ph: number,
  ): React.CSSProperties => ({
    position: "absolute",
    left: cx * width + Math.sin(t * sx + ph) * 120 - r,
    top: cy * height + Math.cos(t * sy + ph) * 90 - r,
    width: r * 2,
    height: r * 2,
    borderRadius: "50%",
    background: `radial-gradient(circle, ${color} 0%, transparent 68%)`,
  });

  const beam = (left: string, base: number, ph: number): React.CSSProperties => ({
    position: "absolute",
    top: -160,
    left,
    width: 520,
    height: 1500,
    transformOrigin: "50% 0%",
    transform: `rotate(${base + Math.sin(t * 0.5 + ph) * 3}deg)`,
    background: `linear-gradient(180deg, ${theme.colors.beam} 0%, transparent 72%)`,
    clipPath: "polygon(42% 0, 58% 0, 100% 100%, 0 100%)",
    filter: "blur(26px)",
    opacity: 0.8 + Math.sin(t * 0.9 + ph) * 0.12,
  });

  return (
    <AbsoluteFill style={{background: theme.colors.bgDeep, overflow: "hidden"}}>
      <div style={blob(0.2, 0.25, 640, theme.colors.meshC, 0.35, 0.28, 0)} />
      <div style={blob(0.85, 0.2, 520, theme.colors.meshB, 0.3, 0.4, 2)} />
      <div style={blob(0.55, 0.95, 700, theme.colors.meshA, 0.25, 0.33, 4)} />
      <div style={beam("6%", -17, 0)} />
      <div style={beam("68%", 17, 2)} />
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: 0,
          height: "42%",
          background: `repeating-linear-gradient(90deg, ${theme.colors.heroFaint} 0 120px, transparent 120px 240px)`,
          WebkitMaskImage: "linear-gradient(180deg, transparent, black)",
          maskImage: "linear-gradient(180deg, transparent, black)",
          opacity: 0.35,
        }}
      />
      <Dust count={26} />
    </AbsoluteFill>
  );
};

// Slow rising golden dust.
export const Dust: React.FC<{count: number; speed?: number; size?: number}> = ({
  count,
  speed = 18,
  size = 5,
}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;
  const items = Array.from({length: count}, (_, i) => {
    const x = rand(i + 1) * width + Math.sin(t * 0.6 + i) * 24;
    const y = (((rand(i + 50) * height - t * speed * (0.6 + rand(i + 9))) % height) + height) % height;
    const s = size * (0.5 + rand(i + 21));
    const o = 0.18 + 0.32 * (0.5 + 0.5 * Math.sin(t * 1.6 + i * 2.1));
    return (
      <div
        key={i}
        style={{
          position: "absolute",
          left: x,
          top: y,
          width: s,
          height: s,
          borderRadius: "50%",
          background: theme.colors.heroSoft,
          opacity: o,
          boxShadow: `0 0 ${s * 3}px ${theme.colors.heroGlow}`,
        }}
      />
    );
  });
  return <AbsoluteFill style={{pointerEvents: "none"}}>{items}</AbsoluteFill>;
};

// Layer 4: colour grade.
export const Grade: React.FC = () => (
  <AbsoluteFill
    style={{
      background: `linear-gradient(180deg, ${theme.colors.gradeTop} 0%, transparent 45%, ${theme.colors.gradeBottom} 100%)`,
      mixBlendMode: "soft-light",
      pointerEvents: "none",
    }}
  />
);

// Layer 5a: film grain.
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{mixBlendMode: "overlay", opacity: 0.14, pointerEvents: "none"}}>
      <svg width="100%" height="100%">
        <filter id="gz-grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves={2} seed={frame % 12} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#gz-grain)" />
      </svg>
    </AbsoluteFill>
  );
};

// Layer 5b: vignette.
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at 50% 50%, transparent 52%, ${theme.colors.vignette} 100%)`,
      pointerEvents: "none",
    }}
  />
);
