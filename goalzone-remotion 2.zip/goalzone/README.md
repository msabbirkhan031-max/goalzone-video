# Goal Zone Khulna — Launch Teaser (Remotion)

- Composition: `Main` — 1920x1080, 30 FPS, 1038 frames (34.6 s)
- Entry: `src/index.ts`
- Colour scheme: Golden Night Pitch (all constants in `src/theme.ts`)
- Timing: `src/timeline.ts` (scene boundaries + SFX cues, in seconds, from the SRT/voiceover)
- Voiceover on/off, SFX on/off: `src/config.ts`
- SFX are original synthesized WAVs in `public/sfx/` (regenerate: `npm run sfx`)
- Fonts: Hind Siliguri (Bengali + Latin) loaded via @remotion/google-fonts — internet needed on first Studio/render run.

Commands:
    npm install
    npx remotion studio
    npx remotion render src/index.ts Main out/video.mp4
