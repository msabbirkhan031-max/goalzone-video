// Original synthesized SFX (no external assets, no copyright). Run: node scripts/make-sfx.mjs
import {writeFileSync, mkdirSync} from "node:fs";

const SR = 44100;
mkdirSync("public/sfx", {recursive: true});

let seed = 1234567;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296 * 2 - 1;
};

const writeWav = (name, samples) => {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0);
  buf.writeUInt32LE(36 + n * 2, 4);
  buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write("data", 36);
  buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  writeFileSync(`public/sfx/${name}.wav`, buf);
};

const gen = (dur, fn) => {
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(i / SR, i, n);
  return out;
};

// one-pole low-pass
const lowpass = (x, cutoff) => {
  const a = 1 - Math.exp((-2 * Math.PI * cutoff) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const highpass = (x, cutoff) => {
  const lp = lowpass(x, cutoff);
  return x.map((v, i) => v - lp[i]);
};
const fadeEdges = (x, inMs = 2, outMs = 12) => {
  const a = Math.floor((inMs / 1000) * SR);
  const b = Math.floor((outMs / 1000) * SR);
  for (let i = 0; i < a && i < x.length; i++) x[i] *= i / a;
  for (let i = 0; i < b && i < x.length; i++) x[x.length - 1 - i] *= i / b;
  return x;
};
const normalize = (x, peak) => {
  let m = 0;
  for (const v of x) m = Math.max(m, Math.abs(v));
  return x.map((v) => (v / (m || 1)) * peak);
};

// POP: short sine with fast pitch drop
const pop = fadeEdges(
  normalize(
    gen(0.16, (t) => {
      const f = 620 - 380 * Math.min(1, t / 0.08);
      return Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 32);
    }),
    0.8,
  ),
);
writeWav("pop", pop);

// CLICK: filtered noise burst + tiny tone
const click = fadeEdges(
  normalize(
    highpass(
      gen(0.07, (t) => (rnd() * 0.8 + Math.sin(2 * Math.PI * 1800 * t) * 0.4) * Math.exp(-t * 95)),
      900,
    ),
    0.7,
  ),
  1,
  6,
);
writeWav("click", click);

// TICK: very small high click
const tick = fadeEdges(
  normalize(
    gen(0.04, (t) => Math.sin(2 * Math.PI * 2600 * t) * Math.exp(-t * 160)),
    0.55,
  ),
  1,
  4,
);
writeWav("tick", tick);

// WHOOSH: band-pass-ish noise sweep (low-pass sweep + high-pass), smooth fade, ~0.7s
{
  const dur = 0.7;
  const n = Math.floor(dur * SR);
  const raw = new Float32Array(n);
  let y = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const p = t / dur;
    const cutoff = 300 + 3200 * Math.sin(Math.PI * Math.min(1, p)) ** 1.5;
    const a = 1 - Math.exp((-2 * Math.PI * cutoff) / SR);
    y += a * (rnd() - y);
    const env = Math.sin(Math.PI * p) ** 2;
    raw[i] = y * env;
  }
  writeWav("whoosh", fadeEdges(normalize(highpass(raw, 180), 0.7), 5, 30));
}

// CHIME: soft pluck + overtone, short decay, ~0.5s
const chime = fadeEdges(
  normalize(
    gen(0.5, (t) => {
      const e = Math.exp(-t * 7);
      return (
        (Math.sin(2 * Math.PI * 880 * t) * 0.7 +
          Math.sin(2 * Math.PI * 1320 * t) * 0.35 +
          Math.sin(2 * Math.PI * 2640 * t) * 0.1) *
        e *
        Math.min(1, t / 0.004)
      );
    }),
    0.7,
  ),
  1,
  40,
);
writeWav("chime", chime);

// IMPACT: very soft low thump, ~0.45s
const impact = fadeEdges(
  normalize(
    lowpass(
      gen(0.45, (t) => {
        const f = 90 - 40 * Math.min(1, t / 0.25);
        return Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 9) + rnd() * 0.08 * Math.exp(-t * 40);
      }),
      400,
    ),
    0.75,
  ),
  2,
  40,
);
writeWav("impact", impact);

console.log("SFX written to public/sfx");
